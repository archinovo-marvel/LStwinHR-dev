param(
    [string]$Name,

    [string]$Description = '',

    [switch]$Private,

    [ValidateSet('ssh', 'https')]
    [string]$Protocol = 'ssh',

    [string]$SshHost = 'github.com',

    [string]$RemoteName = 'origin',

    [switch]$NoSetRemote,

    [switch]$NoPush,

    [string]$Org,

    [switch]$OpenRepo
)

$ErrorActionPreference = 'Stop'

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

if (-not $Name) {
    $Name = Read-Host "Name"
}

if (-not $Name) {
    throw "Name 不能为空。"
}

if ($Protocol -eq 'ssh' -and -not $PSBoundParameters.ContainsKey('SshHost')) {
    $useAlias = Read-Host "是否使用 SSH Host 别名？(y/N)"
    if ($useAlias -match '^(y|yes)$') {
        $aliasInput = Read-Host "请输入 SSH Host 别名（直接回车默认 github-sunner）"
        if (-not [string]::IsNullOrWhiteSpace($aliasInput)) {
            $SshHost = $aliasInput.Trim()
        } else {
            $SshHost = 'github-sunner'
        }
    }
}

function Write-Step {
    param(
        [string]$Title,
        [string]$Color = 'Cyan'
    )

    Write-Host ""
    Write-Host "== $Title ==" -ForegroundColor $Color
}

function Write-Info {
    param([string]$Message)
    Write-Host "  $Message" -ForegroundColor DarkGray
}

function Get-RepoVisibility {
    if ($Private) { return 'private' }
    return 'public'
}

function Get-ExistingRemoteUrl {
    param([string]$Name)
    try {
        return (& git remote get-url $Name 2>$null).Trim()
    } catch {
        return ''
    }
}

function Resolve-RemoteUrl {
    param(
        [string]$SshUrl,
        [string]$HttpsUrl
    )

    if ($Protocol -eq 'ssh') {
        if ($SshHost -and $SshHost -ne 'github.com' -and $SshUrl -match '^git@github\.com:(.+)$') {
            return "git@${SshHost}:$($Matches[1])"
        }
        return $SshUrl
    }
    return $HttpsUrl
}

function Ensure-VisibilityWithGh {
    param(
        [string]$RepoNameWithOwner
    )

    if (-not $Private) { return }

    $gh = Get-Command gh -ErrorAction SilentlyContinue
    if (-not $gh) { return }

    Write-Step "仓库可见性"
    Write-Host "  设置仓库为 private..." -ForegroundColor Cyan
    & gh repo edit $RepoNameWithOwner --visibility private --accept-visibility-change-consequences 2>&1 | Out-Host
}

function Ensure-VisibilityWithApi {
    param(
        [string]$RepoNameWithOwner
    )

    if (-not $Private) { return }

    $token = Get-GitHubToken
    if (-not $token) { return }

    Write-Step "仓库可见性"
    Write-Host "  通过 GitHub API 设置仓库为 private..." -ForegroundColor Cyan

    $headers = @{
        Authorization = "Bearer $token"
        Accept        = 'application/vnd.github+json'
        'User-Agent'  = 'LStwinHR-PowerShell-Scripts'
    }

    Invoke-RestMethod `
        -Method Patch `
        -Uri "https://api.github.com/repos/$RepoNameWithOwner" `
        -Headers $headers `
        -Body (@{ private = $true } | ConvertTo-Json) | Out-Null
}

function Get-GitHubToken {
    if ($env:GITHUB_TOKEN) { return $env:GITHUB_TOKEN }
    if ($env:GH_TOKEN) { return $env:GH_TOKEN }
    return $null
}

function Get-SetupGuideMessage {
    return @"
未检测到可用的 GitHub API 凭据。

推荐方案 A：安装并登录 GitHub CLI
  1. winget install --id GitHub.cli
  2. 重新打开 PowerShell
  3. gh auth login

推荐方案 B：设置环境变量 Token
  1. 创建一个具有 repo 权限的 Personal Access Token
  2. 在当前 PowerShell 执行：
     `$env:GITHUB_TOKEN="你的token"

然后重新运行：
  .\create-github-repo.ps1 -Name "LStwinHR" -Description "AI HR platform" -Private
"@
}

function Create-WithGh {
    $gh = Get-Command gh -ErrorAction SilentlyContinue
    if (-not $gh) { return $null }

    $target = if ($Org) { "$Org/$Name" } else { $Name }
    $args = @('repo', 'create', $target)

    if ($Private) {
        $args += '--private'
    } else {
        $args += '--public'
    }

    if ($Description) {
        $args += @('--description', $Description)
    }

    Write-Step "使用 gh 创建 GitHub 仓库"
    Write-Info "目标仓库: $target"
    & gh @args 2>&1 | Tee-Object -Variable ghOutput | Out-Host
    if ($LASTEXITCODE -ne 0) {
        $ghText = ($ghOutput | Out-String)
        if ($ghText -match 'Name already exists on this account') {
            Write-Host "  仓库已存在，改为接管已有仓库。" -ForegroundColor Yellow
        } else {
            throw "gh repo create 失败。"
        }
    }

    $repoJson = & gh repo view $target --json url,sshUrl,nameWithOwner 2>$null | ConvertFrom-Json
    if (-not $repoJson) {
        return $null
    }

    return @{
        NameWithOwner = $repoJson.nameWithOwner
        HtmlUrl       = $repoJson.url
        SshUrl        = $repoJson.sshUrl
        HttpsUrl      = "https://github.com/$($repoJson.nameWithOwner).git"
    }
}

function Create-WithApi {
    $token = Get-GitHubToken
    if (-not $token) {
        throw (Get-SetupGuideMessage)
    }

    $headers = @{
        Authorization = "Bearer $token"
        Accept        = 'application/vnd.github+json'
        'User-Agent'  = 'LStwinHR-PowerShell-Scripts'
    }

    $body = @{
        name        = $Name
        description = $Description
        private     = [bool]$Private
    }

    if ($Org) {
        $uri = "https://api.github.com/orgs/$Org/repos"
        Write-Step "通过 GitHub API 创建组织仓库"
        Write-Info "组织: $Org"
    } else {
        $uri = 'https://api.github.com/user/repos'
        Write-Step "通过 GitHub API 创建个人仓库"
    }

    try {
        $repo = Invoke-RestMethod -Method Post -Uri $uri -Headers $headers -Body ($body | ConvertTo-Json)
    } catch {
        $errorMessage = $_.Exception.Message
        if ($errorMessage -match '422' -or $errorMessage -match 'already exists') {
            Write-Host "  仓库已存在，改为读取已有仓库信息。" -ForegroundColor Yellow

            $repoPath = if ($Org) { "$Org/$Name" } else {
                $viewer = Invoke-RestMethod -Method Get -Uri 'https://api.github.com/user' -Headers $headers
                "$($viewer.login)/$Name"
            }

            $repo = Invoke-RestMethod -Method Get -Uri "https://api.github.com/repos/$repoPath" -Headers $headers
        } else {
            throw
        }
    }

    return @{
        NameWithOwner = $repo.full_name
        HtmlUrl       = $repo.html_url
        SshUrl        = $repo.ssh_url
        HttpsUrl      = $repo.clone_url
        DefaultBranch = $repo.default_branch
    }
}

function Ensure-Remote {
    param(
        [string]$RemoteUrl
    )

    if ($NoSetRemote) {
        Write-Step "远程绑定"
        Write-Host "  已跳过远程绑定（NoSetRemote）。" -ForegroundColor Yellow
        return
    }

    $existingUrl = Get-ExistingRemoteUrl -Name $RemoteName
    Write-Step "配置 Git 远程"
    if ($existingUrl) {
        Write-Host "  更新远程 $RemoteName -> $RemoteUrl" -ForegroundColor Cyan
        & git remote set-url $RemoteName $RemoteUrl
    } else {
        Write-Host "  新增远程 $RemoteName -> $RemoteUrl" -ForegroundColor Cyan
        & git remote add $RemoteName $RemoteUrl
    }

    if ($LASTEXITCODE -ne 0) {
        throw "配置 git remote 失败。"
    }
}

function Ensure-InitialPush {
    param(
        [string]$RepoNameWithOwner
    )

    if ($NoPush) {
        Write-Step "初次推送"
        Write-Host "  已跳过初次推送（NoPush）。" -ForegroundColor Yellow
        return
    }

    $branch = (& git branch --show-current).Trim()
    if (-not $branch) {
        throw "未检测到当前分支，无法推送到 $RepoNameWithOwner。"
    }

    $status = & git status --porcelain
    if ($status) {
        Write-Step "初次推送"
        Write-Warning "当前工作区仍有未提交改动，已跳过自动推送。请先提交后再执行 .\push-github.ps1。"
        return
    }

    Write-Step "初次推送"
    Write-Host "  推送当前分支到远程..." -ForegroundColor Cyan
    & git push -u $RemoteName $branch
    if ($LASTEXITCODE -ne 0) {
        throw "git push 失败。"
    }
}

$repoInfo = $null

try {
    $repoInfo = Create-WithGh
    if (-not $repoInfo) {
        Write-Step "回退到 GitHub API" "Yellow"
        Write-Info "未检测到可用 gh，尝试使用 API 创建或接管仓库"
        $repoInfo = Create-WithApi
    }
} catch {
    Write-Warning $_.Exception.Message
    Write-Step "回退到 GitHub API" "Yellow"
    Write-Info "尝试使用 API 创建或接管仓库"
    $repoInfo = Create-WithApi
}

if (-not $repoInfo) {
    throw "创建仓库失败，未获得仓库信息。"
}

$remoteUrl = Resolve-RemoteUrl -SshUrl $repoInfo.SshUrl -HttpsUrl $repoInfo.HttpsUrl

try {
    Ensure-VisibilityWithGh -RepoNameWithOwner $repoInfo.NameWithOwner
} catch {
    Write-Warning "使用 gh 设置 private 失败，尝试改用 GitHub API。"
    Ensure-VisibilityWithApi -RepoNameWithOwner $repoInfo.NameWithOwner
}

Ensure-Remote -RemoteUrl $remoteUrl
Ensure-InitialPush -RepoNameWithOwner $repoInfo.NameWithOwner

Write-Host ""
Write-Host "远程仓库已就绪" -ForegroundColor Green
Write-Host "仓库:    $($repoInfo.NameWithOwner)" -ForegroundColor Yellow
Write-Host "网页:    $($repoInfo.HtmlUrl)" -ForegroundColor Yellow
Write-Host "远程:    $remoteUrl" -ForegroundColor Yellow
Write-Host ""
Write-Host "后续常用命令：" -ForegroundColor Cyan
Write-Host '  .\git-quick-status.ps1' -ForegroundColor DarkGray
Write-Host '  .\push-github.ps1 -Message "your commit message"' -ForegroundColor DarkGray

if ($OpenRepo) {
    Start-Process $repoInfo.HtmlUrl
}
